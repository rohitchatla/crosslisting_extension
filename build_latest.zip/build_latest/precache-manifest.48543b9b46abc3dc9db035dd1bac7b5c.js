self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9ffae4d078484b58679ba1b09bd672ed",
    "url": "/index.html"
  },
  {
    "revision": "7788a05b460aac1101c9",
    "url": "/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "3fdad5fff99894806bec",
    "url": "/static/js/2.c4eeba2a.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.c4eeba2a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7788a05b460aac1101c9",
    "url": "/static/js/main.1d57c688.chunk.js"
  },
  {
    "revision": "1e41b8449cf7d77a117c",
    "url": "/static/js/runtime-main.fd70dc08.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);