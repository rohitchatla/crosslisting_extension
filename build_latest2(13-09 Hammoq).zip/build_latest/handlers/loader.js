import("./utils/_.js").then(() => {
  console.log("scripts imported ");
});
